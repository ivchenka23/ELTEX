#!/bin/bash

CONF="observer.conf"
LOG="observer.log"

while read script; do
    [ -z "$script" ] && continue
    [[ "$script" == \#* ]] && continue

    found=0
    for pid in /proc/[0-9]*; do
        [ -d "$pid" ] || continue
        cmd=$(tr -d '\0' < "$pid/cmdline" 2>/dev/null)
        if [[ "$cmd" == *"$script"* ]]; then
            found=1
            break
        fi
    done

    if [ $found -eq 0 ]; then
        echo "$(date '+%F %T') Restarted $script" >> "$LOG"
        nohup ./"$script" >/dev/null 2>&1 &
        sleep 2
    fi
done < "$CONF"
