#!/bin/bash

WORK_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$WORK_DIR"

PIPE="/tmp/run/cuckoo.pid"
LOG_FILE="cuckoo.log"

mkdir -p /tmp/run

rm -f "$PIPE"
mkfifo "$PIPE"

log_msg() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

cleanup() {
    log_msg "Shutdown!"
    rm -f "$PIPE"
    exit 0
}

trap cleanup SIGTERM SIGINT

log_msg "Startup!"

while true; do
    if read -r line < "$PIPE"; then
        if [[ $line =~ ^(.+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\? ]]; then
            name="${BASH_REMATCH[1]}"
            pid="${BASH_REMATCH[2]}"
            n=$(( (RANDOM % 9) + 2 ))
            log_msg "$name[$pid] $n"
            echo "$n" > "/tmp/run/resp_$pid"
        fi
    fi
done
