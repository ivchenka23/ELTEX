#!/bin/bash

SCRIPT_NAME=$(basename "$0")

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

LOG="report_${SCRIPT_NAME}.log"
PIPE="/tmp/run/cuckoo.pid"
PID=$$

sleep $((RANDOM % 3))

echo "$(date '+%F %T') [$PID] Скрипт запущен" >> "$LOG"

echo "$SCRIPT_NAME[$PID]: how much time do I have?" > "$PIPE"

while [ ! -f "/tmp/run/resp_$PID" ]; do
    sleep 0.1
done

N=$(cat "/tmp/run/resp_$PID")
rm -f "/tmp/run/resp_$PID"

sleep "$N"

echo "$(date '+%F %T') [$PID] Скрипт завершился, работал $N секунд." >> "$LOG"
